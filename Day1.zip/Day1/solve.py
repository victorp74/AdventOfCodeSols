
import io
import numpy as np

with open("AdventOfCodeDay1.txt", "r") as outfile:
    data = outfile.read()
# a = list(sorted(map(sum, map(lambda x: map(lambda y: int(y) if y.isnumeric() else 0, x.split("\n")), data.split("\n\n")))))
# print(a[-1])
# print(sum(a[-3:]))

file = open("AdventOfCodeDay1.txt","r")
fileContent = file.readlines()
print(fileContent)
num =0
arrayElfs = []
for i in (fileContent):
    #print(i)
    if(i=='\n'):
        arrayElfs.append(num)
        num = 0
    else:
        num+=int(i)

print(arrayElfs)
greatestElfCalorie = 0
greatestElf = 0
for i in range(len(arrayElfs)):
    if(arrayElfs[i]>greatestElfCalorie):
        greatestElfCalorie = arrayElfs[i]
        greatestElf = i
arrayElfs.sort()
print(arrayElfs)
print(greatestElfCalorie)
    